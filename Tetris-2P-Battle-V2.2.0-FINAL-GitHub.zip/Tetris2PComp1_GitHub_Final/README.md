# 🎮 2-Player Tetris Battle V2.2.0 - M5StickC Plus2

**Professional 2-player Tetris battle system with enhanced gameplay features and WiFi networking**

![Version](https://img.shields.io/badge/version-2.2.0-blue)
![Device](https://img.shields.io/badge/device-M5StickC%20Plus2-orange)
![License](https://img.shields.io/badge/license-MIT-green)

## 🚀 **One-Click Installation**

### **M5Burner Installation (Recommended)**
1. Download **`TETRIS_V2.2.0_FINAL_M5BURNER.bin`** from releases
2. Open M5Burner application
3. Flash to M5StickC Plus2 - done!

### **Manual Installation**
```bash
git clone https://github.com/Coreymillia/Tetris-for-M5StickCPlus2-FastGhost.git
cd Tetris-for-M5StickCPlus2-FastGhost
pio run --target upload
```

## ✨ **Key Features**

### 🎮 **Enhanced Tetris Gameplay**
- ✅ **HOLD System** - Store pieces strategically (BtnA)
- ✅ **NEXT Preview** - See upcoming pieces
- ✅ **Ghost Pieces** - Perfect placement guidance
- ✅ **20 Speed Levels** - From beginner (1000ms) to impossible (30ms)
- ✅ **Progressive Lock Delay** - Optimized for each skill level
- ✅ **Standard Colors** - Classic Tetris piece colors

### ⚔️ **2-Player WiFi Battles**
- ✅ **Wireless Multiplayer** - No cables needed
- ✅ **Garbage Attack System** - "ATK!" and "HIT!" mechanics  
- ✅ **Mixed Skill Battles** - Different players, different speeds
- ✅ **Synchronized Gameplay** - Perfect timing control
- ✅ **Win/Lose Detection** - Proper competitive endings

### 🎨 **Professional UI**
- ✅ **Smart Blue Borders** - Clean field boundaries
- ✅ **Organized Layout** - HOLD/NEXT areas clearly defined
- ✅ **Battle Meter** - Real-time opponent status
- ✅ **60fps Performance** - Smooth, responsive gameplay

## 🎯 **How to Play**

### **Single Player**
1. Power on device
2. Press M5 button to start
3. Select level (0-19) with Left/Right buttons
4. Press M5 to begin game

### **2-Player Battle Setup**
1. **Device 1**: Press Left+Right buttons → HOST battle
2. **Device 2**: Press UP → SCAN and connect
3. Both players select their preferred level
4. Game shows "BATTLE MODE! 3 2 1 GO!" countdown
5. Battle begins - clear lines to attack opponent!

## 🎮 **Controls**

| Input | Action |
|-------|--------|
| **M5 Button** | Rotate piece / Start game |
| **BtnA (Left)** | HOLD current piece |
| **BtnB (Right)** | Soft drop |
| **Joystick** | Move piece left/right |
| **PWR Button** | Pause / Reset |

### **Battle Mode Setup**
| Input | Action |
|-------|--------|
| **Left+Right** | Host WiFi battle |
| **UP** | Scan for battles |
| **Left/Right** | Select level |

## 🏆 **Battle System**

### **Attack Mechanics**
- **2 Lines (Double)** → 1 garbage row sent
- **3 Lines (Triple)** → 2 garbage rows sent  
- **4 Lines (Tetris)** → 4 garbage rows sent
- **T-Spins** → Bonus attack damage

### **Victory Conditions**
- First player to **top out** loses
- Game displays "YOU WIN!" / "YOU LOSE"
- Automatic return to level select

## 🔧 **Technical Specifications**

- **Platform**: M5StickC Plus2 (ESP32-PICO-V3-02)
- **Network**: WiFi P2P battle communication
- **Display**: 135x240 pixel TFT
- **Performance**: 60fps smooth gameplay
- **Memory**: 15.4% RAM, 78.5% Flash
- **Battery**: Real-time level monitoring

## 📁 **Project Structure**

```
src/
├── main.cpp              # Core game engine
├── wifi_beacon.cpp       # Tetris-themed WiFi beacons
├── wifi_scanner.cpp      # Network discovery
├── UNIT_MiniJoyC.cpp     # Joystick controller
└── tet.h                 # Graphics assets
```

## 🙏 **Credits & Attribution**

This project builds upon excellent work from multiple sources in the community:

### **🎯 Original Tetris Implementation**
- **Primary Foundation**: [AleksAlcDel/Tetris-for-M5StickCPlus2](https://github.com/AleksAlcDel/Tetris-for-M5StickCPlus2)
  - Original M5StickC Plus2 Tetris implementation
  - Core game engine and display optimization
  - Basic controls and piece mechanics
  - MIT Licensed foundational code

### **🌐 Advanced Tetris Concepts & Inspiration**
- **Tetris Game Logic**: [Hexagon/detris](https://github.com/Hexagon/detris)
  - Modern Tetris mechanics and scoring concepts
  - Battle mode garbage system inspiration
  - Advanced game state management ideas
  - MIT Licensed reference implementation
  - Copyright (c) 2023 Hexagon

### **⚔️ Battle Mode Implementation (100% Original)**
- **2-Player WiFi Battle System**: Custom implementation for this project
- **Real-time P2P Communication**: ESP32 WiFi Direct protocol
- **Garbage Attack Mechanics**: Classic Tetris battle rules implementation
- **Synchronized Gameplay**: Custom timing and state management

### **🚀 Enhanced Features (Original Implementation)**
- **HOLD System**: Complete implementation with visual feedback and storage
- **NEXT Piece Preview**: Enhanced preview system with proper positioning
- **Ghost Piece System**: Real-time placement preview following modern standards
- **Progressive Lock Delay**: Custom timing system optimized for different skill levels
- **20-Level Speed System**: Comprehensive difficulty progression (30ms to 1000ms)
- **Smart UI Borders**: Clean visual boundaries with professional layout

### **📚 Libraries & Dependencies**
- **M5StickCPlus2**: Official M5Stack library
- **M5Unified**: M5Stack unified development framework
- **WiFi**: ESP32 core networking capabilities
- **Graphics**: M5GFX display system
- **JoyC Controller**: M5Stack UNIT_MiniJoyC library

### **👥 Development Team**
- **Enhanced Battle Implementation**: coreymillia + GitHub Copilot CLI
- **Original M5StickC Plus2 Foundation**: AleksAlcDel
- **Tetris Concepts Reference**: Hexagon (detris project)
- **Testing & Optimization**: Community feedback and extensive playtesting
- **Professional Polish**: Enhanced UI, documentation, and distribution

## 📋 **Version History**

- **v2.2.0**: Official release with Tetris theme, smart borders, production quality
- **v2.1.0**: Enhanced UI with blue borders and corner gaps  
- **v2.0.0**: Full 2-player battles with garbage attacks
- **v1.9.0**: Synchronized gameplay and level selection
- **v1.5.0**: HOLD, NEXT, progressive features added

## 📄 **License**

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🚀 **Contributing**

Contributions welcome! Please feel free to submit issues, feature requests, or pull requests.

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

**Made with ❤️ for the M5Stack community**
- **Right side button**: Hard drop (plummet)
- **Both side buttons**: WiFi beacon mode
- **Up on joystick**: WiFi scanner mode
- **Down on joystick at startup**: Battle mode

## Network Setup:
1. One player selects "Down" at startup first (becomes HOST)  
2. Second player selects "Down" at startup (becomes CLIENT)
3. Devices connect automatically via WiFi
4. Both players can start playing after connection established

## Battle Victory Conditions:
- Survive longer than opponent (don't let blocks reach top)
- Send garbage rows to opponent by clearing lines
- Strategic HOLD usage for better line clears

## Technical Implementation:
- Built on PlatformIO with ESP32 framework
- M5StickCPlus2 hardware with JoyC controller
- WiFi UDP communication for real-time battles  
- Enhanced game mechanics with proper timing systems
- No broken attack features from 2PTetris4 (avoided those completely)

**Status: ✅ Successfully compiled and ready for deployment!**